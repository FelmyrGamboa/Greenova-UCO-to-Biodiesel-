# Process Control Panel – Raspberry Pi

A Flask web page on the Raspberry Pi that:

- controls the **ESP32** (dispensers, pumps, oil, valve, electrode, heater, mixers 1 and 2 with RPM) through the **USB serial cable** using the ESP32's serial commands (WiFi is optional)
- has a **serial console** on the page and an API so your own Python scripts can send ESP32 commands
- shows the **temperature** from the ESP32's DS18B20
- controls the **centrifuge** DC motor from the Pi's own GPIO (0–2500 RPM, soft start/stop, timer)
- shows the **load cell** (HX711) weight at the bottom of the page, with Tare and Calibrate

Works on Raspberry Pi 3, 4 and 5 (Raspberry Pi OS Bookworm).

## Wiring (BCM / GPIO numbers)

| Part | Signal | Pi GPIO | Physical pin |
|---|---|---|---|
| Centrifuge driver (BTS7960) | L_EN | GPIO 23 | 16 |
| | R_EN | GPIO 24 | 18 |
| | LPWM | GPIO 25 | 22 |
| | RPWM | GPIO 21 | 40 |
| HX711 | DT | GPIO 17 | 11 |
| | SCK | GPIO 27 | 13 |

- Power the **HX711 from 3.3V** (Pi pin 1), not 5V, so its DT signal is safe for the Pi.
- Connect the Pi GND to the motor driver GND and the HX711 GND.
- The centrifuge runs forward on RPWM. To spin the other way, set `"direction": "reverse"` in `config.json`.

## Install

```bash
sudo apt update
sudo apt install -y python3-flask python3-requests python3-serial python3-lgpio unzip
sudo usermod -aG dialout,gpio $USER     # serial port + GPIO access, then reboot
```

Copy the `pi_control` folder to `/home/pi/pi_control`. The web page is built into `app.py`, so there is no `templates` folder.

## Connect the ESP32

1. Upload the updated `esp32_process_control.ino` to the ESP32 (it adds the `json` status command the Pi needs).
2. Plug the ESP32 into a USB port on the Pi.
3. The app finds it automatically (`/dev/ttyUSB0` or `/dev/ttyACM0`). To pick a port yourself, set it under **Settings** or in `"esp32_port"` in `config.json`.

Close the Arduino Serial Monitor and any other program using the port: only one program can open a serial port at a time.

To use WiFi instead of the cable, choose **WiFi** under Settings and enter the IP the ESP32 prints in its Serial Monitor.

## Send ESP32 commands from your own Python script

While the app is running it owns the serial port, so send commands through the app instead of opening the port again:

```python
import requests
PI = "http://127.0.0.1:5000"          # or http://<pi-ip>:5000 from another computer

requests.post(PI + "/api/esp/cmd", json={"cmd": "pumpin on 30"})
requests.post(PI + "/api/esp/cmd", json={"cmd": "mixer1 rpm 800"})
requests.post(PI + "/api/centrifuge/set", json={"state": "on", "rpm": 2000, "dur": 60})

s = requests.get(PI + "/api/status").json()
print(s["esp32"]["temp"], s["loadcell"]["weight"])
```

Any command from the ESP32 command list works in `cmd` (`help`, `status`, `alloff`, `heater on 120`, ...).

## Run

```bash
cd /home/pi/pi_control
python3 app.py
```

The browser on the Pi's screen opens the page by itself (`http://127.0.0.1:5000`). It uses Chromium if it is installed, otherwise the default browser. From a phone or PC on the same network, open the address the terminal prints: `http://<pi-ip>:5000`.

- Don't want the browser to open? Run `python3 app.py --no-browser`, or set `"open_browser": false` in `config.json`.
- Touch screen? Set `"browser_kiosk": true` to open full screen without an address bar (press Alt+F4 to close it).
- Started over SSH? There is no screen there, so no browser opens. Start it from a terminal on the Pi's desktop.

## Start automatically at boot

Pick **one** of these.

### Option A: start with the desktop and open the browser (Pi with a screen)

```bash
mkdir -p ~/.config/autostart
cp /home/pi/pi_control/pi-control.desktop ~/.config/autostart/
```

After the next reboot and desktop login, the app starts and the browser opens the page. The log goes to `/home/pi/pi_control/app.log`. Edit the paths inside `pi-control.desktop` first if your folder isn't `/home/pi/pi_control`. For this to work without typing a password, turn on desktop auto-login: `sudo raspi-config` → System Options → Boot / Auto Login → Desktop Autologin.

### Option B: start as a background service (no screen needed, no browser)

```bash
sudo cp pi-control.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now pi-control
```

Edit `User=` and the paths in `pi-control.service` first if your username isn't `pi`.

Useful commands:

```bash
sudo systemctl status pi-control     # is it running?
journalctl -u pi-control -f          # live log
sudo systemctl restart pi-control    # after editing config.json
```

## Calibrate the load cell

The page has a **Calibration** section under the weight reading:

1. **Empty the scale** and press **Zero (empty scale)**. It averages 3 seconds of readings to set the `offset`.
2. **Put a known weight on** (for example 500 g), type `500`, pick the unit and press **Calculate factor**. It averages 3 seconds and sets
   `calibration_factor = (raw reading - offset) / known weight`.
3. **Check** that the reading shows your weight. Try a second weight to confirm.

`offset` and `calibration_factor` are saved in `config.json`, so they stay after a reboot. A negative factor is normal if the load cell is wired the other way round. You can also type a factor in by hand with **Set factor manually**, for example one from an Arduino HX711 sketch.

Use **Tare** any time later to re-zero (for a container) without changing the factor.

From Python:

```python
requests.post(PI + "/api/loadcell/tare")                              # step 1, scale empty
requests.post(PI + "/api/loadcell/calibrate", json={"weight": 500})   # step 2, 500 g on it
```

## Settings in `config.json`

| Setting | Meaning |
|---|---|
| `esp32_mode` | `serial` (USB cable, default) or `http` (WiFi) |
| `esp32_port` | Serial port, or `auto` |
| `esp32_baud` | Serial speed, must match the sketch (115200) |
| `esp32_url` | ESP32 address, only used in `http` mode |
| `web_port` | Web page port (default 5000) |
| `open_browser` | Open the page on the Pi's screen at start (`true`/`false`) |
| `browser_kiosk` | Open full screen without an address bar (`true`/`false`) |
| `centrifuge.max_rpm` | RPM at 100% PWM (2500) |
| `centrifuge.min_duty` | Raise (e.g. 15–25) if the motor hums but won't start at low RPM |
| `centrifuge.ramp_seconds` | Soft start/stop time from 0 to full speed |
| `centrifuge.pwm_freq` | PWM frequency in Hz |
| `loadcell.offset` | Raw reading with the scale empty (set by Zero / Tare) |
| `loadcell.calibration_factor` | Raw counts per unit (set by Calculate factor) |
| `loadcell.cal_seconds` | How long each calibration step averages readings (3) |
| `loadcell.unit` | Unit label shown on the page (calibrate in the same unit) |
| `loadcell.samples` | Median filter size; higher is steadier but slower |

RPM is open-loop (calculated from PWM), so it is an estimate. Exact RPM needs a speed sensor on the shaft.

## Testing on a PC

If there is no Raspberry Pi GPIO, the app starts in **simulation mode** (a yellow banner shows on the page) so you can check the interface on a laptop: `pip install flask requests pyserial` then `python3 app.py`.

## API summary

| Method | Path | Body (JSON) |
|---|---|---|
| GET | `/api/status` | – |
| POST | `/api/esp/cmd` | `{"cmd": "pumpin on 30"}` |
| POST | `/api/esp/set` | `{"dev": "valve", "state": "on", "dur": 10}` |
| POST | `/api/esp/rpm` | `{"dev": "mixer2", "rpm": 1200}` |
| POST | `/api/centrifuge/set` | `{"state": "on", "rpm": 2000, "dur": 60}` |
| POST | `/api/centrifuge/rpm` | `{"rpm": 1500}` |
| POST | `/api/loadcell/tare` | – |
| POST | `/api/loadcell/calibrate` | `{"weight": 500, "unit": "g"}` |
| POST | `/api/loadcell/factor` | `{"calibration_factor": -421.4}` |
| POST | `/api/alloff` | – |
